<?php

namespace TaylorJ\Blogs\Reaction;

use XF\MVC\Entity\Entity;
use XF\Reaction\AbstractHandler;

class BlogPost extends AbstractHandler
{
    public function reactionsCounted(Entity $entity)
    {
        return ($entity->blog_post_state === 'visible' || $entity->blog_post_state == 'scheduled');
    }
}

