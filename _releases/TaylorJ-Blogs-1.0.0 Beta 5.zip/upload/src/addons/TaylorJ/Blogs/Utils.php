<?php

namespace TaylorJ\Blogs;

use XF\Repository\PostRepository;

class Utils
{

    public static function hours()
    {
        $hours = [];
        for ($i = 0; $i < 24; $i++) {
            $hh = str_pad($i, 2, '0', STR_PAD_LEFT);
            $hours[$hh] = $hh;
        }

        return $hours;
    }

    public static function minutes()
    {
        $minutes = [];
        for ($i = 0; $i < 60; $i += 1) {
            $mm = str_pad($i, 2, '0', STR_PAD_LEFT);
            $minutes[$mm] = $mm;
        }

        return $minutes;
    }

    public static function repo($class)
    {
        return \XF::app()->repository($class);
    }

    public static function log($msg)
    {
        \XF::logError('[TaylorJ\Blogs] --> ' . $msg);
    }

    /**
     * @return \XF\Repository\Thread
     */
    public static function getBlogPostRepo()
    {
        return \XF::app()->repository('TaylorJ\Blogs:BlogPost');
    }

    /**
     * @return PostRepository
     */
    public function getPostRepo()
    {
        return \XF::app()->repository(PostRepository::class);
    }
}
