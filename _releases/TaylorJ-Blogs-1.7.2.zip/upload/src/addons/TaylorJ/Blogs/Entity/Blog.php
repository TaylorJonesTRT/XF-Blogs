<?php

namespace TaylorJ\Blogs\Entity;

use TaylorJ\Blogs\Utils;
use XF\Entity\ApprovalQueue;
use XF\Entity\DatableInterface;
use XF\Entity\DatableTrait;
use XF\Entity\User;
use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;
use XF\Mvc\Router;

/**
 * COLUMNS
 * @property int $blog_id
 * @property int $user_id
 * @property string $blog_title
 * @property string $blog_title_
 * @property string $blog_description
 * @property string $blog_description_
 * @property int $blog_creation_date
 * @property int $blog_last_post_date
 * @property bool $blog_has_header
 * @property int $blog_post_count
 * @property string $blog_state
 *
 * GETTERS
 * @property-read string $blog_header_image
 *
 * RELATIONS
 * @property-read User|null $User
 * @property-read \XF\Mvc\Entity\AbstractCollection<\TaylorJ\Blogs\Entity\BlogPost> $BlogPost
 * @property-read \XF\Mvc\Entity\AbstractCollection<\TaylorJ\Blogs\Entity\BlogWatch> $BlogWatch
 * @property-read ApprovalQueue|null $ApprovalQueue
 */
class Blog extends Entity implements DatableInterface
{
    use DatableTrait;

    public function getBreadcrumbs($includeSelf = true, $linkType = 'public')
    {
        if ($linkType == 'public')
        {
            $link = 'blogs/blog';
        }
        return $this->_getBreadcrumbs($includeSelf, $linkType, $link);
    }

    public function canView(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($visitor->user_id == $this->user_id)
        {
            return $visitor->hasPermission('taylorjBlogs', 'viewOwn');
        }

        return $visitor->hasPermission('taylorjBlogs', 'viewAny');
    }

    public function canEdit(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($visitor->user_id == $this->user_id)
        {
            if (!$visitor->hasPermission('taylorjBlogs', 'canEditOwn'))
            {
                $error = \XF::phrase('taylorj_blogs_blog_error_edit');
                return false;
            }
        } else
        {
            if (!$visitor->hasPermission('taylorjBlogs', 'canEditAny'))
            {
                $error = \XF::phrase('taylorj_blogs_blog_error_edit');
                return false;
            }
        }

        return true;
    }

    public function canDelete($type = 'soft', &$error = null)
    {
        $visitor = \XF::visitor();

        if ($type != 'soft')
        {
            return $visitor->hasPermission('taylorjBlogs', 'canHardDeleteAny');
        }

        if ($visitor->hasPermission('taylorjBlogs', 'canDeleteAny'))
        {
            return true;
        }

        return (
            $this->user_id == $visitor->user_id
            && $visitor->hasPermission('taylorjBlogs', 'canDeleteOwn')
        );
    }

    public function canUndelete(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($visitor->hasPermission('taylorjBlogs', 'canUndeleteAny'))
        {
            return true;
        }

        return (
            $this->user_id == $visitor->user_id
            && $visitor->hasPermission('taylorjBlogs', 'canUndeleteOwnBlog')
        );
    }

    public function canPost(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($this->user_id === $visitor->user_id)
        {
            if (!$visitor->hasPermission('taylorjBlogPost', 'canPost'))
            {
                $error = \XF::phrase('taylorj_blogs_blog_post_error_new');
                return false;
            } else
            {
                return true;
            }
        }
        return false;
    }

    public function canWatch(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($this->user_id === $visitor->user_id)
        {
            return false;
        }

        return true;
    }

    public function canViewScheduledPosts(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($this->user_id === $visitor->user_id)
        {
            return true;
        }

        return false;
    }

    public function canEditTags(?BlogPost $blogPost = null, &$error = null)
    {
        $visitor = \XF::visitor();

        if (!$this->app()->options()->enableTagging)
        {
            return false;
        }

        // if no blog post, assume will be owned by this person
        if ($visitor->hasPermission('taylorjBlogPost', 'canTagOwnBlogPost'))
        {
            return true;
        }

        return (
            $visitor->hasPermission('taylorjBlogPost', 'canTagAnyBlogPost')
            || $visitor->hasPermission('taylorjBlogPost', 'canManageAnyTag')
        );
    }

    public function canSetPublicDeleteReason()
    {
        $visitor = \XF::visitor();

        return (
            $visitor->user_id
            && $visitor->user_id != $this->user_id
            // technically can allow this for own blog owners, but may be somewhat confusing
        );
    }

    public function canSendModeratorActionAlert()
    {
        $visitor = \XF::visitor();

        return (
            $visitor->user_id
            && $this->blog_state == 'visible'
        );
    }

    public function getBlogHeaderImage(bool $canonical = false): string
    {
        $blogHeaderImage = $this->app()->applyExternalDataUrl(
            "taylorj_blogs/blog_header_images/{$this->blog_id}.jpg",
            $canonical
        );

        if (!$this->blog_has_header)
        {
            return false;
        }


        return $blogHeaderImage;
    }

    public function getBlogPostCount(): int
    {
        return $this->finder('TaylorJ\Blogs:BlogPost')
            ->inBlogId($this->blog_id)
            ->visiblePosts()
            ->total();
    }

    public function getAbstractedHeaderImagePath($sizeCode = null)
    {
        $blogId = $this->blog_id;

        return sprintf(
            'data://taylorj_blogs/blog_header_images/%d.jpg',
            $blogId,
        );
    }

    public function getIconUrl($sizeCode = null, $canonical = false)
    {
        $app = $this->app();

        if ($this->blog_header_image)
        {
            $group = floor($this->blog_id);
            return $app->applyExternalDataUrl(
                "taylorj_blogs/blog_header_images/{$this->blog_id}.jpg?{$this->blog_creation_date}",
                $canonical
            );
        } else
        {
            return null;
        }
    }

    protected function verifyTitle(&$value)
    {
        if (strlen($value) < 10)
        {
            $this->error(\XF::phrase('taylorj_blogs_titile_verification_error'), 'title');
            return false;
        }

        $value = utf8_ucwords($value);

        return true;
    }

    public function canUploadAndManageAttachments()
    {
        $visitor = \XF::visitor();

        //TODO: decide later on if we should have a permission for allowing the
        // use of the attachment system for posts
        return true;
    }

    public function canApproveUnapprove(&$error = null)
    {
        return (
            \XF::visitor()->user_id
            && \XF::visitor()->hasPermission('forum', 'approveUnapprove')
        );
    }

    public function getNewBlogPost()
    {
        $blogPost = $this->_em->create('TaylorJ\Blogs:BlogPost');
        $blogPost->blog_id = $this->blog_id;

        return $blogPost;
    }

    public function getNewContentState(?Blog $blog = null)
    {
        $visitor = \XF::visitor();

        if ($visitor->user_id && $visitor->hasPermission('forum', 'approveUnapprove'))
        {
            return 'visible';
        }

        if (!$visitor->hasPermission('general', 'submitWithoutApproval'))
        {
            return 'moderated';
        }

        return \XF::app()->options()->taylorjBlogsBlogApproval ? 'moderated' : 'visible';
    }

    public function getContentDateColumn(): string
    {
        return 'blog_creation_date';
    }

    protected function blogMadeVisible()
    {
        if ($this->BlogPosts->count())
        {
            foreach ($this->BlogPosts AS $blogPost)
            {
                $blogPost->blog_post_state = 'visible';
                $blogPost->save();
            }
        }
    }

    public function isVisible()
    {
        return ($this->blog_state == 'visible');
    }

    public function isOwner()
    {
        if (\XF::visitor()->user_id != $this->user_id)
        {
            return false;
        }

        return true;
    }

    protected function submitHamData()
    {
        /** @var ContentChecker $submitter */
        $submitter = $this->app()->container('spam.contentHamSubmitter');
        $submitter->submitHam('taylorj_blogs_blog', $this->blog_id);
    }

    protected function _postSave()
    {
        $visibilityChange = $this->isStateChanged('blog_state', 'visible');
        $approvalChange = $this->isStateChanged('blog_state', 'moderated');
        $deletionChange = $this->isStateChanged('blog_post_state', 'deleted');

        if ($approvalChange == 'enter')
        {
            $approvalQueue = $this->getRelationOrDefault('ApprovalQueue', false);
            $approvalQueue->content_date = $this->blog_creation_date;
            $approvalQueue->save();
        }

        if (!$this->isUpdate())
        {
            (new Utils())->adjustUserBlogCount($this, 1);
        }

        if ($this->isUpdate())
        {
            if ($visibilityChange == 'enter')
            {

                $this->blogMadeVisible();

                if ($approvalChange)
                {
                    $this->submitHamData();
                }
            } else if ($deletionChange == 'enter' && !$this->DeletionLog)
            {
                $delLog = $this->getRelationOrDefault('DeletionLog', false);
                $delLog->setFromVisitor();
                $delLog->save();
            }

            if ($approvalChange == 'leave' && $this->ApprovalQueue)
            {
                $this->ApprovalQueue->delete();
            }
        }
    }

    public function softDelete($reason = '', ?User $byUser = null)
    {
        $byUser = $byUser ?: \XF::visitor();

        if ($this->blog_state == 'deleted')
        {
            return false;
        }

        $this->blog_state = 'deleted';

        /** @var DeletionLog $deletionLog */
        $deletionLog = $this->getRelationOrDefault('DeletionLog');
        $deletionLog->setFromUser($byUser);
        $deletionLog->delete_reason = $reason;

        $this->save();

        return true;
    }

    protected function _preDelete()
    {
        Utils::getBlogRepo()->deleteBlogHeaderImage($this);
    }

    protected function _postDelete()
    {
        foreach ($this->BlogPosts AS $blogPost)
        {
            $blogPost->delete();
        }
    }

    public static function getStructure(Structure $structure): Structure
    {
        $structure->table = 'xf_taylorj_blogs_blog';
        $structure->shortName = 'TaylorJ\Blogs:Blog';
        $structure->contentType = 'taylorj_blogs_blog';
        $structure->primaryKey = 'blog_id';
        $structure->columns = [
            'blog_id' => ['type' => self::UINT, 'autoIncrement' => true],
            'user_id' => ['type' => self::UINT, 'default' => \XF::visitor()->user_id],
            'blog_title' => ['type' => self::STR, 'maxLength' => 50, 'required' => true, 'censor' => true],
            'blog_description' => ['type' => self::STR, 'maxLength' => 255, 'required' => false, 'censor' => true],
            'blog_creation_date' => ['type' => self::UINT, 'default' => \XF::$time],
            'blog_last_post_date' => ['type' => self::UINT, 'default' => 0],
            'blog_has_header' => ['type' => self::BOOL, 'default' => false],
            'blog_state' => [
                'type' => self::STR,
                'default' => 'visible',
                'allowedValues' => ['visible', 'moderated', 'deleted'],
            ],
            'blog_post_count' => ['type' => self::UINT, 'default' => 0],
        ];
        $structure->relations = [
            'User' => [
                'entity'     => 'XF:User',
                'type'       => self::TO_ONE,
                'conditions' => 'user_id',
                'primary'    => true,
            ],
            'BlogPosts' => [
                'entity'	=> 'TaylorJ\Blogs:BlogPost',
                'type'		=> self::TO_MANY,
                'conditions' => 'blog_id',
                'primary'	=> true,
            ],
            'BlogWatch' => [
                'entity' => 'TaylorJ\Blogs:BlogWatch',
                'type' => self::TO_MANY,
                'conditions' => 'blog_id',
                'key' => 'user_id',
            ],
            'ApprovalQueue' => [
                'entity' => 'XF:ApprovalQueue',
                'type' => self::TO_ONE,
                'conditions' => [
                    ['content_type', '=', 'taylorj_blogs_blog'],
                    ['content_id', '=', '$blog_id'],
                ],
                'primary' => true,
            ],
            'DeletionLog' => [
                'entity' => 'XF:DeletionLog',
                'type' => self::TO_ONE,
                'conditions' => [
                    ['content_type', '=', 'taylorj_blogs_blog'],
                    ['content_id', '=', '$blog_id'],
                ],
                'primary' => true,
            ],
        ];
        $structure->defaultWith = ['User'];
        $structure->getters = [
            'blog_header_image' => true,
            'blog_post_count' => true,
        ];
        $structure->behaviors = [
            'XF:Taggable' => ['stateField' => 'blog_post_state'],
            'XF:Indexable' => [
                'checkForUpdates' => ['blog_title', 'blog_description', 'blog_id', 'blog_last_post_date', 'user_id'],
            ],
        ];

        return $structure;
    }

    protected function _getBreadcrumbs($includeSelf, $linkType, $link)
    {
        /** @var Router $router */
        $router = $this->app()->container('router.' . $linkType);
        $structure = $this->structure();

        $output = [];
        if ($includeSelf)
        {
            $output[] = [
                'value' => $this->blog_title,
                'href' => $router->buildLink($link, $this),
                $structure->primaryKey => $this->{$structure->primaryKey},
            ];
        }

        return $output;
    }
}
